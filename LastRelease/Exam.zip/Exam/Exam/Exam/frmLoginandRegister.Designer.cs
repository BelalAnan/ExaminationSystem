﻿
namespace Exam
{
    partial class frmLoginandRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginbutt = new System.Windows.Forms.Button();
            this.Registerbut = new System.Windows.Forms.Button();
            this.registerpanel = new System.Windows.Forms.Panel();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtConfirmpassword = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtZipCode = new System.Windows.Forms.TextBox();
            this.btnRegister = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBoxclose = new System.Windows.Forms.PictureBox();
            this.registerpanelsmall = new System.Windows.Forms.Panel();
            this.loginpanelsmall = new System.Windows.Forms.Panel();
            this.btnLogin = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtLoginEmail = new System.Windows.Forms.TextBox();
            this.textbox = new System.Windows.Forms.Label();
            this.txtLoginPassword = new System.Windows.Forms.TextBox();
            this.loginpanel = new System.Windows.Forms.Panel();
            this.registerpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxclose)).BeginInit();
            this.loginpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // loginbutt
            // 
            this.loginbutt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.loginbutt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginbutt.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.loginbutt.FlatAppearance.BorderSize = 0;
            this.loginbutt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginbutt.Font = new System.Drawing.Font("Tahoma", 14F);
            this.loginbutt.ForeColor = System.Drawing.Color.White;
            this.loginbutt.Location = new System.Drawing.Point(122, 12);
            this.loginbutt.Name = "loginbutt";
            this.loginbutt.Size = new System.Drawing.Size(251, 71);
            this.loginbutt.TabIndex = 0;
            this.loginbutt.Text = "LOG-IN";
            this.loginbutt.UseVisualStyleBackColor = false;
            this.loginbutt.Click += new System.EventHandler(this.loginbutt_Click);
            // 
            // Registerbut
            // 
            this.Registerbut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.Registerbut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Registerbut.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.Registerbut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Registerbut.Font = new System.Drawing.Font("Tahoma", 14F);
            this.Registerbut.ForeColor = System.Drawing.Color.White;
            this.Registerbut.Location = new System.Drawing.Point(600, 12);
            this.Registerbut.Name = "Registerbut";
            this.Registerbut.Size = new System.Drawing.Size(251, 71);
            this.Registerbut.TabIndex = 1;
            this.Registerbut.Text = "Register";
            this.Registerbut.UseVisualStyleBackColor = false;
            this.Registerbut.Click += new System.EventHandler(this.Registerbut_Click);
            // 
            // registerpanel
            // 
            this.registerpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.registerpanel.Controls.Add(this.txtLastName);
            this.registerpanel.Controls.Add(this.label11);
            this.registerpanel.Controls.Add(this.label10);
            this.registerpanel.Controls.Add(this.txtStreet);
            this.registerpanel.Controls.Add(this.txtCity);
            this.registerpanel.Controls.Add(this.label9);
            this.registerpanel.Controls.Add(this.txtEmail);
            this.registerpanel.Controls.Add(this.label6);
            this.registerpanel.Controls.Add(this.txtConfirmpassword);
            this.registerpanel.Controls.Add(this.label5);
            this.registerpanel.Controls.Add(this.txtPassword);
            this.registerpanel.Controls.Add(this.label3);
            this.registerpanel.Controls.Add(this.txtZipCode);
            this.registerpanel.Controls.Add(this.btnRegister);
            this.registerpanel.Controls.Add(this.label2);
            this.registerpanel.Controls.Add(this.txtFirstName);
            this.registerpanel.Controls.Add(this.label1);
            this.registerpanel.Location = new System.Drawing.Point(34, 104);
            this.registerpanel.Name = "registerpanel";
            this.registerpanel.Size = new System.Drawing.Size(921, 362);
            this.registerpanel.TabIndex = 2;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(443, 47);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(266, 20);
            this.txtLastName.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(267, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 24);
            this.label11.TabIndex = 17;
            this.label11.Text = "Street :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(267, 123);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 24);
            this.label10.TabIndex = 16;
            this.label10.Text = "City :";
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(443, 161);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(266, 20);
            this.txtStreet.TabIndex = 15;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(443, 123);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(266, 20);
            this.txtCity.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(267, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 24);
            this.label9.TabIndex = 13;
            this.label9.Text = "Zip Code :";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(443, 199);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(266, 20);
            this.txtEmail.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(267, 199);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Email :";
            // 
            // txtConfirmpassword
            // 
            this.txtConfirmpassword.Location = new System.Drawing.Point(443, 275);
            this.txtConfirmpassword.Name = "txtConfirmpassword";
            this.txtConfirmpassword.Size = new System.Drawing.Size(266, 20);
            this.txtConfirmpassword.TabIndex = 10;
            this.txtConfirmpassword.UseSystemPasswordChar = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(267, 275);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 24);
            this.label5.TabIndex = 9;
            this.label5.Text = "Confirm Password :";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(443, 237);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(266, 20);
            this.txtPassword.TabIndex = 8;
            this.txtPassword.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(267, 237);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "Password :";
            // 
            // txtZipCode
            // 
            this.txtZipCode.Location = new System.Drawing.Point(443, 85);
            this.txtZipCode.Name = "txtZipCode";
            this.txtZipCode.Size = new System.Drawing.Size(266, 20);
            this.txtZipCode.TabIndex = 6;
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(152)))), ((int)(((byte)(219)))));
            this.btnRegister.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRegister.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegister.Font = new System.Drawing.Font("Tahoma", 15F);
            this.btnRegister.ForeColor = System.Drawing.Color.White;
            this.btnRegister.Location = new System.Drawing.Point(271, 321);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(438, 38);
            this.btnRegister.TabIndex = 4;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(267, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Last Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(443, 9);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(266, 20);
            this.txtFirstName.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(267, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name :";
            // 
            // pictureBoxclose
            // 
            this.pictureBoxclose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxclose.ImageLocation = "../../images/x.png";
            this.pictureBoxclose.Location = new System.Drawing.Point(961, 12);
            this.pictureBoxclose.Name = "pictureBoxclose";
            this.pictureBoxclose.Size = new System.Drawing.Size(16, 16);
            this.pictureBoxclose.TabIndex = 3;
            this.pictureBoxclose.TabStop = false;
            this.pictureBoxclose.Click += new System.EventHandler(this.pictureBoxclose_Click);
            // 
            // registerpanelsmall
            // 
            this.registerpanelsmall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.registerpanelsmall.Location = new System.Drawing.Point(600, 89);
            this.registerpanelsmall.Name = "registerpanelsmall";
            this.registerpanelsmall.Size = new System.Drawing.Size(251, 8);
            this.registerpanelsmall.TabIndex = 12;
            // 
            // loginpanelsmall
            // 
            this.loginpanelsmall.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.loginpanelsmall.Location = new System.Drawing.Point(124, 89);
            this.loginpanelsmall.Name = "loginpanelsmall";
            this.loginpanelsmall.Size = new System.Drawing.Size(249, 8);
            this.loginpanelsmall.TabIndex = 13;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(148)))), ((int)(((byte)(6)))));
            this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogin.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.Font = new System.Drawing.Font("Tahoma", 15F);
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(271, 199);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(438, 38);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "Log-in";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 15F);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(267, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 24);
            this.label8.TabIndex = 5;
            this.label8.Text = "Email :";
            // 
            // txtLoginEmail
            // 
            this.txtLoginEmail.Location = new System.Drawing.Point(443, 85);
            this.txtLoginEmail.Name = "txtLoginEmail";
            this.txtLoginEmail.Size = new System.Drawing.Size(266, 20);
            this.txtLoginEmail.TabIndex = 6;
            // 
            // textbox
            // 
            this.textbox.AutoSize = true;
            this.textbox.Font = new System.Drawing.Font("Tahoma", 15F);
            this.textbox.ForeColor = System.Drawing.Color.White;
            this.textbox.Location = new System.Drawing.Point(267, 128);
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(107, 24);
            this.textbox.TabIndex = 7;
            this.textbox.Text = "Password :";
            // 
            // txtLoginPassword
            // 
            this.txtLoginPassword.Location = new System.Drawing.Point(443, 128);
            this.txtLoginPassword.Name = "txtLoginPassword";
            this.txtLoginPassword.Size = new System.Drawing.Size(266, 20);
            this.txtLoginPassword.TabIndex = 8;
            this.txtLoginPassword.UseSystemPasswordChar = true;
            // 
            // loginpanel
            // 
            this.loginpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.loginpanel.Controls.Add(this.txtLoginPassword);
            this.loginpanel.Controls.Add(this.textbox);
            this.loginpanel.Controls.Add(this.txtLoginEmail);
            this.loginpanel.Controls.Add(this.label8);
            this.loginpanel.Controls.Add(this.btnLogin);
            this.loginpanel.Location = new System.Drawing.Point(34, 104);
            this.loginpanel.Name = "loginpanel";
            this.loginpanel.Size = new System.Drawing.Size(921, 362);
            this.loginpanel.TabIndex = 11;
            // 
            // frmLoginandRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(46)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(989, 568);
            this.Controls.Add(this.loginpanelsmall);
            this.Controls.Add(this.registerpanelsmall);
            this.Controls.Add(this.pictureBoxclose);
            this.Controls.Add(this.Registerbut);
            this.Controls.Add(this.loginbutt);
            this.Controls.Add(this.loginpanel);
            this.Controls.Add(this.registerpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmLoginandRegister";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmLoginandRegister_Load);
            this.registerpanel.ResumeLayout(false);
            this.registerpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxclose)).EndInit();
            this.loginpanel.ResumeLayout(false);
            this.loginpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button loginbutt;
        private System.Windows.Forms.Button Registerbut;
        private System.Windows.Forms.Panel registerpanel;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox txtConfirmpassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtZipCode;
        private System.Windows.Forms.PictureBox pictureBoxclose;
        private System.Windows.Forms.Panel registerpanelsmall;
        private System.Windows.Forms.Panel loginpanelsmall;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtLoginEmail;
        private System.Windows.Forms.Label textbox;
        private System.Windows.Forms.TextBox txtLoginPassword;
        private System.Windows.Forms.Panel loginpanel;
    }
}

